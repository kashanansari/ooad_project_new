﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class student_dashboard : Form
    {
        public student_dashboard()
        {
            InitializeComponent();
        }
        //public string WelcomeMessage
        //{
        //    set { welcomeLabel.Text = value; } 
        //}

        private void student_dashboardcs_Load(object sender, EventArgs e)
        {

        }
    }
}
